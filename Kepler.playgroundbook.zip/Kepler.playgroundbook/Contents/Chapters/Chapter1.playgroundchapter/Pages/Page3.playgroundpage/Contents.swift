/*:
 * Callout(The Third Law of Kepler):
 _The square of the orbital period of a planet is directly proportional to the cube of the semi-major axis of its orbit._
*/
 
/*:
 I know I know... Math class nightmares are probably haunting you right now, so let's keep it simple:
 
 The semimajor axis of an ellipse is actually the average distance from the sun, if you cube it and take the square of the revolution period, their ratio will always be a constant value that depends on the mass of the planet.
 
 So what about trying to change the average distance of our earth from the sun? In our simulated earth of course... doing that for real would be bad!
 Use the `addEarth(at: Float)` command from before, but now with a twist! It's up to you to decide at which distance to place the earth, you can put any number that goes from 0.5 to 5.0, and see by yourself how even small changes do influence the revolution period a lot, since cubes and squares are involved. Also feel free to use this command with the other ones you learned.
*/
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, setSimulationSpeed(to: ), addEarth(at: ), showAreas())
//#-code-completion(description, show, "setSimulationSpeed(to: Int)", "addEarth(at: Float)")
//#-editable-code Tap to enter code
//#-end-editable-code
 
//: So thank you for your time, hope you enjoyed the ride as much as I did in preparing it. Bye bye and stay in orbit!
