import Foundation
import SpriteKit
import PlaygroundSupport

public func setSimulationSpeed (to value: Int) {
    var floatValue = CGFloat(value)
    if value < 1 {
         floatValue = 1
    } else if value > 100 {
        floatValue = 100
    }
    SimulationManager.shared.simulationSpeed = floatValue
}

public func addEarth() {
    SimulationManager.shared.addEarth(at: 1.0)
}

public func showAreas() {
    
    SimulationManager.shared.showAreas = true
    
}

public func addEarth(at distance: Float){
    var floatValue = Double(distance)
    if distance < 0.5 {
        floatValue = 0.5
    } else if distance > 5.0 {
        floatValue = 5.0
    }
    SimulationManager.shared.addEarth(at: floatValue)
}

