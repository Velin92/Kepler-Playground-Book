import PlaygroundSupport
import SpriteKit




public func setup(){
    // Setup the Live View
    PlaygroundPage.current.liveView = nil
    SimulationManager.shared.liveViewSetup()
    // Define hints and solution
    //PlaygroundPage.current.assessmentStatus = PlaygroundPage.AssessmentStatus.fail(hints: , solution: )
}
