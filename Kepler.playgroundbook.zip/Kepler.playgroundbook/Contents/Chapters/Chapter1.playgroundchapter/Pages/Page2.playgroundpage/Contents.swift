/*:
 * Callout(The Second Law of Kepler):
_A line joining a planet and the Sun sweeps out equal areas during equal intervals of time._
*/

/*:
 This is actually very cool! Since the Sun has a huge gravitational pull, a planet the closer gets to it, needs more speed to escape and not becoming a roasted planet while the farther it gets the slower it becomes to stay in orbit and not becoming a frozen one. However even if the speed is always changing, something remains constant, and that's the areal speed! Look how our earth sweeps the same amount of area around the sun every second, use `showAreas()` along the other commands you learned, and get amazed by how beautiful is this law.
*/
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, setSimulationSpeed(to: ), addEarth(), showAreas())
//#-code-completion(description, show, "setSimulationSpeed(to: Int)")
//#-editable-code Tap to enter code
//#-end-editable-code

//: [Next: The Third Law of Kepler](@next)
