//: # Welcome To Kepler
//: Kepler is a simple and fun way to visualize the three laws of Kepler. So what are we even waiting for? Let's dive directly into...

/*:
* Callout(The First Law of Kepler):
_The orbit of every planet is an ellipse with the Sun at one of the two foci._
*/

/*:
 But what is an ellipse? What are the foci? And why they are so hard to pronounce?
 
 Unfortunately I don't have an answer for the latter but I can tell you that an ellipse is a geometric shape in which every point on its perimeter has always the sum of the distances from two points, called foci, constant.
 Now watch the first law in action by yourself, type in the code editor below the command `addEarth()` and execute the code.
 
 Also if you find the simulation a bit too slow or too fast, you can change its speed by typing the command `setSimulationSpeed(to: Int)`.
 The default value is 30 which means that the orbit is simulating 30 days per second but you can put any integer number going from 1 to 100.
*/

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, setSimulationSpeed(to: ), addEarth())
//#-code-completion(description, show, "setSimulationSpeed(to: Int)")
//#-editable-code Tap to enter code
//#-end-editable-code

//:[Next: The Second Law of Kepler](@next)
