import Foundation
import SpriteKit
import UIKit

public class OrbitNode: SKNode {
    
    //the center of the ellipse node
    public let centerNode = SKNode()
    public var sun = Sun()
    public var earthSprite: Earth?
    //this node is used to have a clear separation on the earthNode speed
    //and the simulation speed
    public var simulationNode = SimulationNode()
    public var orbit: SKShapeNode
    public var sweepingAreaSpeed: CGFloat {
        get {
            return SimulationManager.shared.simulationSpeed * Constants.ellipseArea / CGFloat(earthSprite!.revolutionTimeDays)
        }
    }
    public var simulation = SKAction()
    //the timer to show areas
    public var time: TimeInterval = 1.0
    //to draw areaa shape
    public var areaPath: CGMutablePath = CGMutablePath()
    public var previousEarthPosition = CGPoint(x: Constants.ellipseValueA, y: 0)
    //to keep track of the shown areas
    public var areaShapes: [SKShapeNode] = []
    
    
    public override init() {
        self.orbit = SKShapeNode(ellipseOf: Constants.ellipseSize)
        super.init()
        self.centerNode.position = Constants.orbitNodeCenter
        self.addChild(centerNode)
        self.centerNode.addChild(sun)
        centerNode.zPosition = 1.0
        simulationNode.speed = SimulationManager.shared.simulationSpeed
        
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func update(deltaTime: TimeInterval) {
        guard let earth = earthSprite else { return }
        //to tune the speed of the earthNode according to the second law of Kepler
        speedTuning(deltaTime: deltaTime, earth: earth)
        if SimulationManager.shared.showAreas {
            measureArea(deltaTime: deltaTime)
            drawLine()
        }

        
    }
    
    //used to get the distance between 2 points
    public func distance(first: CGPoint, second: CGPoint) -> CGFloat{
        let squaredX = (first.x - second.x) * (first.x - second.x)
        let squaredY = (first.y - second.y) * (first.y - second.y)
        return sqrt(squaredX + squaredY)
        
    }
    
    //Heron formula to calculate the area of a triangle given three edges
    public func calculateArea(base: CGFloat, previousEdge: CGFloat, currentEdge: CGFloat) -> CGFloat{
        let p = (base + previousEdge + currentEdge)/2
        let pA = p - base
        let pB = p - previousEdge
        let pC = p - currentEdge
        return sqrt(p * pA * pB * pC)
    }
    
    //the function used to speed tune the earthNode
    public func speedTuning(deltaTime: TimeInterval, earth: Earth) {
        self.simulationNode.speed = SimulationManager.shared.simulationSpeed
        let base = distance(first: earth.position, second: simulationNode.earthNode.position)
        if base != 0 {
            //the best way I found to implement the second law of kepler, without using more complex differential approximations, the error on the area speed is about +/-3% around the correct value. What I actually do with scaleArea is get the ratio between a radius of a circle with the same area of the ellipse and of a circle with radius r = a, the semimajor axis, this is to correct the max speed. Each frame then I take the area of the triangle created by the previous position, the sun, and the current position, then I get the height of this triangle to have an average distance from the sun between to the two frames. I then multiply the scaleArea with the ratio between the average distance of the earth from the sun (the semimajor axis) and the current average height between the frames. This tunes the speed accordingly to create a pretty accurate simulation without using more complex calculations. 
            let previousDistance = distance(first: sun.position, second: earth.position)
            let currentDistance = distance (first: sun.position, second: simulationNode.earthNode.position)
            let area = calculateArea(base: base, previousEdge: previousDistance, currentEdge: currentDistance)
            let height = area * 2 / base
            let speed = Constants.scaleArea * Constants.ellipseValueA/height
            simulationNode.earthNode.speed = speed
            self.previousEarthPosition = earth.position
            earth.position = simulationNode.earthNode.position
            
        }
    }
    
    //used to create the area shapes
    public func measureArea(deltaTime: TimeInterval) {
        
        if time <= 0 {
            time = 1.0
            areaPath.addLine(to: previousEarthPosition)
            areaPath.addLine(to: sun.position)
            areaPath.closeSubpath()
            let pathCopy = areaPath.mutableCopy()
            addArea(path: pathCopy!)
            areaPath = CGMutablePath()
        }  else if time != 1.0 {
            areaPath.addLine(to: previousEarthPosition)
        }
        if time == 1.0 {
            areaPath.move(to: sun.position)
            areaPath.addLine(to: previousEarthPosition)
        }
        
        time -= deltaTime
    }
    //used to create a line joining the earth and the sun every frame
    public func drawLine() {
        centerNode.childNode(withName: "line")?.removeFromParent()
        let path = CGMutablePath()
        path.move(to: sun.position)
        path.addLine(to: earthSprite!.position)
        let shape = SKShapeNode()
        shape.name = "line"
        shape.path = path
        shape.strokeColor = UIColor.white
        shape.lineWidth = 2
        centerNode.addChild(shape)
    }
    //used to add the earth in an empty simulation
    public func addEarth(earth: Earth) {
        earthSprite = earth
        self.centerNode.addChild(orbit)
        self.centerNode.addChild(earthSprite!)
        self.centerNode.addChild(simulationNode)
        self.simulation = SKAction.repeatForever(SKAction.follow(orbit.path!, asOffset: false, orientToPath: true, duration: earth.revolutionTimeDays))
        simulationNode.earthNode.run(simulation)
        simulationNode.earthNode.speed = Constants.scaleArea * Constants.ellipseValueA/distance (first: sun.position, second: simulationNode.earthNode.position)
    }
    
    //uased to always mantain up to 3 areas shown, to not slow down the simulation
    public func addArea(path: CGMutablePath){
        if areaShapes.count == 3 {
            areaShapes.first!.removeFromParent()
            areaShapes.removeFirst()
        }
        let areaShape = SKShapeNode(path: path)
        areaShape.fillColor = SKColor.blue
        self.centerNode.addChild(areaShape)
        areaShapes.append(areaShape)
    }
    
    
    
    
    
    
    
    
    
   
    
}

