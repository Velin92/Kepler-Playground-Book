import Foundation
import SpriteKit

public class OrbitScene: SKScene {
    
    public var backgroundSprite: SKSpriteNode!
    public let labelsNode = SKNode()
    public let orbitNode = OrbitNode()
    public var previousTime: TimeInterval = 0
    public let distanceLabel = SKLabelNode(fontNamed: "Helvetica")
    public let revolutionTimeLabel = SKLabelNode(fontNamed: "Helvetica")
    public let simulationTimeLabel = SKLabelNode(fontNamed: "Helvetica")
   
    
    public override func didMove(to view: SKView) {
        
        sceneSetup()
        
    }
    
    
    public override func update(_ currentTime: TimeInterval) {
        if previousTime == 0 {
            //to have a deltaTime = 0 for the first update
            previousTime = currentTime
        }
        //used to calculate the time between a frame and another
        let deltaTime = currentTime - previousTime
        orbitNode.update(deltaTime: deltaTime)
        updateLabels()
        previousTime = currentTime
    }
    
    //used to update the labels of the simulation
    public func updateLabels() {
        if let earth = orbitNode.earthSprite {
            let roundedDistance = round(earth.distanceAU * 1000)
            let displayDistance = Float(roundedDistance/1000)
            distanceLabel.text = "Average Distance: \(displayDistance) AU"
            let roundedTime = round(earth.revolutionTimeDays * 100)
            let displayTime = Float(roundedTime/100)
            revolutionTimeLabel.text = "Revolution Period: \(displayTime) days"
        }
        let roundedSimTime = Int(SimulationManager.shared.simulationSpeed)
        simulationTimeLabel.text = "Simulation Speed: \(roundedSimTime) days/sec"
    }
    
    //the setup for the scene
    public func sceneSetup() {
        
        self.addChild(orbitNode)
        distanceLabel.text = "Average Distance:"
        distanceLabel.horizontalAlignmentMode = .left
        distanceLabel.position = CGPoint(x: 0, y: 0)
        revolutionTimeLabel.text = "Revolution Period:"
        revolutionTimeLabel.horizontalAlignmentMode = .left
        revolutionTimeLabel.position = CGPoint(x: 0, y: 50)
        simulationTimeLabel.text = "Simulation Speed:"
        simulationTimeLabel.horizontalAlignmentMode = .left
        simulationTimeLabel.position = CGPoint(x:0, y: 100)
        labelsNode.zPosition = 3.0
        addChild(labelsNode)
        labelsNode.addChild(simulationTimeLabel)
        labelsNode.addChild(revolutionTimeLabel)
        labelsNode.addChild(distanceLabel)
        self.backgroundSprite = SKSpriteNode(texture: SimulationManager.shared.backgroundTexture)
        addChild(backgroundSprite)

    }
    
    //to move the nodes in a way that looks nice in landscape
    public func setLandscapeMode(){
        backgroundSprite.zRotation = 0
        orbitNode.position = CGPoint(x:200, y: 0)
        orbitNode.zRotation = 0
        labelsNode.position = CGPoint(x: -750, y: -350)
    }
    
    //the same as above but for portrait
    public func setPortraitMode(){
        backgroundSprite.zRotation = -CGFloat.pi/2
        orbitNode.position = CGPoint(x:0, y: 0)
        orbitNode.zRotation = -CGFloat.pi/2
        labelsNode.position = CGPoint(x: -500, y: -500)
        
    }
    
   
}
