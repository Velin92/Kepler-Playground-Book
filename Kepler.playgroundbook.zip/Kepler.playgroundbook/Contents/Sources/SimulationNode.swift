import Foundation
import SpriteKit

//the node where the actual simulation is happening in this way the speed of this node controls the speed of the earthNode which is inside. So that the earthNode speed depends on it without having to speed tune it accordingly
public class SimulationNode: SKNode {
    
    public let earthNode: SKNode

    
    public override init(){
        earthNode = SKNode()
        earthNode.position = CGPoint(x: Constants.ellipseValueA, y: 0)
        super.init()
        self.addChild(earthNode)
    }
    
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
