import Foundation
import SpriteKit

//inide of this enum I will declare all the constants needed for the simulation
public enum Constants {
    
    public static let sunSize = CGSize(width: 174, height: 174)
    public static let earthSize = CGSize(width: 70, height: 70)
    public static let earthZ = CGFloat(2.0)
    public static let sunZ = CGFloat(1.0)
    public static let ellipseValueB = CGFloat(340.0)
    public static let ellipseValueA = CGFloat(400.0)
    public static let ellipseFocus: CGPoint = {
        let squareA = ellipseValueA * ellipseValueA
        let squareB = ellipseValueB * ellipseValueB
        return CGPoint(x:-sqrt(squareA - squareB), y: 0 )
    }()
    public static let orbitNodeCenter = CGPoint(x: -120, y: 0)
    public static let ellipseSize = CGSize(width: ellipseValueA * 2, height: ellipseValueB * 2)
    public static let defaultSimulationSpeed = CGFloat(30)
    public static let ellipseArea = CGFloat.pi * ellipseValueA * ellipseValueB
    
    public static let ellipseEccentricity: CGFloat = {
        return -ellipseFocus.x/ellipseValueA
    }()
    
    public static let scaleArea: CGFloat = {
        let areaCircle = ellipseValueA * ellipseValueA * CGFloat.pi
        return sqrt(ellipseArea)/sqrt(areaCircle)
    }()
    
}
