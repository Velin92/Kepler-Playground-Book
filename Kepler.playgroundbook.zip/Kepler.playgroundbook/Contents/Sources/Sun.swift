import Foundation
import SpriteKit


public class Sun: SKSpriteNode {
    
    public init() {
        let sunTexture = SimulationManager.shared.sunTexture
        super.init(texture: sunTexture, color: .clear, size: Constants.sunSize)
        self.zPosition = Constants.sunZ
        self.position = Constants.ellipseFocus
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
