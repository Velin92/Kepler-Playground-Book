import Foundation
import SpriteKit
import PlaygroundSupport

//This singleton class is use to be an easy access point for the simulation and the liveView
public class SimulationManager {
    
    //all the textures needed are buffered here to avoid accessing to the filesystem every time.
    public let sunTexture: SKTexture
    public var earthTextures: [SKTexture] = []
    public var backgroundTexture: SKTexture
    public static let shared = SimulationManager()
    //the simulation speed measured in days per second
    public var simulationSpeed = Constants.defaultSimulationSpeed
    public var showAreas = false
    
    init(){
        sunTexture = SKTexture(imageNamed: "sun.png")
        for i in 0...10 {
            earthTextures.append(SKTexture(imageNamed: "earth\(i).png"))
        }
        backgroundTexture = SKTexture(imageNamed: "background.png")
    }
    
    public func liveViewSetup() {
        PlaygroundPage.current.liveView = SceneViewController()
    }
    
    public func addEarth(at distance: Double) {
        liveViewSetup()
        let sceneViewController =  PlaygroundPage.current.liveView as! SceneViewController
        let scene = sceneViewController.scene
        let earth = Earth(distance: distance)
        scene.orbitNode.addEarth(earth: earth)
    }
}
