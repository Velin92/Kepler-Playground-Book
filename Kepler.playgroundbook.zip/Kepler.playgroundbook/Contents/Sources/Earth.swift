import Foundation
import SpriteKit

//the earth sprite class
public class Earth: SKSpriteNode {
    
    public let textures: [SKTexture]
    //the earth average distance measured in Astronomical Units
    public var distanceAU: Double
    //the revolution period measured in days
    public var revolutionTimeDays: Double
    //measured in AU^3/days^2 it's the earth proportional scale
    //for Kepler third Law
    public static let earthThirdLawScale = 0.000007496
    


    //the normal init with the default distance and revolution time
    public init(){
        self.textures = SimulationManager.shared.earthTextures
        self.distanceAU = 1.0
        self.revolutionTimeDays = Earth.timeOfThirdLaw(distance: self.distanceAU)
        super.init(texture: self.textures[0], color: .clear, size: Constants.earthSize)
        self.zPosition = Constants.earthZ
        self.position = CGPoint(x:Constants.ellipseValueA, y: 0)
        let animation = SKAction.repeatForever(SKAction.animate(with: textures, timePerFrame: 1.0/Double(textures.count)))
        //this is to give the earth sprite the famous 23 degrees of inclination on the rotation axis
        self.zRotation = -23*CGFloat.pi/180 + CGFloat.pi/2
        self.run(animation)
    }
    
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //used to calculate the revolution period using the third law of kepler
    //given the distance
    public static func timeOfThirdLaw(distance: Double) -> Double{
        let cubedDistance = distance * distance * distance
        let squaredTime = cubedDistance / Earth.earthThirdLawScale
        let time = sqrt(squaredTime)
        print(time)
        return time
    }
    
    //used to simulate the third law
    public convenience init(distance: Double) {
        self.init()
        self.distanceAU = distance
        self.revolutionTimeDays = Earth.timeOfThirdLaw(distance: self.distanceAU)
    }
    
}
