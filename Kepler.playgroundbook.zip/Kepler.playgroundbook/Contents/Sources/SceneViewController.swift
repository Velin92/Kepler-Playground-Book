import Foundation
import SpriteKit
import UIKit
import PlaygroundSupport

public class SceneViewController: UIViewController {
    
    
    public var scene: OrbitScene {
        get {
            let skView = self.view as! SKView
            let scene = skView.scene as! OrbitScene
            return scene
        }
    }

    public override func viewDidLoad() {
        super.viewDidLoad()
        self.view = SKView()
        let skView = self.view as! SKView
        if let scene = OrbitScene(fileNamed: "OrbitScene") {
            
            scene.scaleMode = .aspectFill
                
            skView.presentScene(scene)
        }
        skView.ignoresSiblingOrder = true
            
        skView.showsFPS = true
        skView.showsNodeCount = true
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        //changing the orientation mode of the scene here because only after the load orientation is set the first time
        self.setSceneMode()
    }
    
    public override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    
    public override func viewWillLayoutSubviews() {
        self.setSceneMode()
    }
    
    //this function recognizes in which kind of view the scene is going to be rendered and calls the appropriate node positioning function for that.
    public func setSceneMode() {
        if self.view.bounds.size.width > self.view.bounds.size.height {
            scene.setLandscapeMode()
        } else {
            scene.setPortraitMode()
        }
    }
    
    
    
    
    
   
}
